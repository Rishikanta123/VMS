﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;
using VMS_1.Models;

namespace VMS_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VisitorRequestController : ControllerBase
    {
        private readonly VMS_DBContext _context;

        public VisitorRequestController(VMS_DBContext context)
        {
            _context = context;
        }

        //   Fetch all Visitor Requests (with optional filters)
        [HttpGet]
        public async Task<IActionResult> GetVisitorRequests(DateTime? visitedFrom = null, DateTime? visitedTo = null,  string? status = null,string? visitorType = null)
        {
            try
            {
                var query = _context.Visits
                    .Include(v => v.Purpose)
                    .Include(v => v.VisitStatus)
                    .Include(v => v.VisitorType)
                    .AsQueryable();

                // 🔹 Filter by Visited From (compare as DateTime)
                if (visitedFrom.HasValue)
                    query = query.Where(v => v.CreatedAt >= visitedFrom.Value);

                // 🔹 Filter by Visited To (compare as DateTime)
                if (visitedTo.HasValue)
                    query = query.Where(v => v.CreatedAt <= visitedTo.Value);

                // 🔹 Filter by Status
                if (!string.IsNullOrEmpty(status))
                    query = query.Where(v => v.VisitStatus.StatusName == status);

                // 🔹 Filter by Visitor Type
                if (!string.IsNullOrEmpty(visitorType))
                    query = query.Where(v => v.VisitorType.VisitorTypeName == visitorType);

                var result = await query
                    .Select(v => new
                    {
                        v.VisitId,
                        v.VisitorName,
                        v.CompanyName,
                        ContactNumber = v.Mobile,
                        v.EmployeeName,
                        v.EmployeeDepartment,
                        v.EmployeeDesignation,
                        VisitTime = v.CreatedAt,
                        Status = v.VisitStatus.StatusName,
                        VisitorType = v.VisitorType.VisitorTypeName
                    })
                    .OrderByDescending(v => v.VisitTime)
                    .ToListAsync();

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error fetching visitors", error = ex.Message });
            }
        }

        //  Forward Visitor Request (Gate User Action)
        [HttpPost("ForwardVisitorRequest")]
        public async Task<IActionResult> ForwardVisitorRequest([FromBody] ForwardVisitorModel model)
        {
            if (model == null || model.VisitId <= 0)
                return BadRequest(new { message = "Invalid visitor data." });

            var visit = await _context.Visits.FirstOrDefaultAsync(v => v.VisitId == model.VisitId);
            if (visit == null)
                return NotFound(new { message = "Visitor not found." });

            // Update visitor request status
            visit.VisitStatusId = model.StatusId;
            visit.Remarks = model.Remarks ?? "Forwarded to concerned employee.";
            visit.ModifiedBy = model.ForwardedBy ?? "GateUser";
            visit.ModifiedAt = DateTime.UtcNow;

            _context.Visits.Update(visit);
            await _context.SaveChangesAsync();

            return Ok(new { success = true, message = "Visitor request forwarded successfully." });
        }

        // Visitor Details by ID
        [HttpGet("GetVisitorById/{id}")]
        public async Task<IActionResult> GetVisitorById(int id)
        {
            var visit = await _context.Visits
                .Include(v => v.VisitorType)
                .Include(v => v.Purpose)
                .Include(v => v.VisitStatus)
                .Include(v => v.Country)
                .Include(v => v.InGate)
                .FirstOrDefaultAsync(v => v.VisitId == id);

            if (visit == null)
                return NotFound(new { message = "Visitor not found." });

            return Ok(visit);
        }

        // Lookup dropdowns (VisitorType, Status, Purpose, Gate)
        [HttpGet("GetLookupData")]
        public async Task<IActionResult> GetLookupData()
        {
            var data = new
            {
                VisitorTypes = await _context.Visitortypes.ToListAsync(),
                StatusList = await _context.Visitstatuses.ToListAsync(),
                PurposeList = await _context.Purposes.ToListAsync(),
                GateList = await _context.Gates.ToListAsync()
            };

            return Ok(data);
        }

        [HttpGet("GetAllVisitorList")]
        public async Task<IActionResult> GetAllVisitorList()
        {
            try
            {
                var list = await _context.Visits
                    .Include(v => v.VisitStatus)
                    .Include(v => v.VisitorType)
                    .Select(v => new
                    {
                        v.VisitId,
                        v.Purpose,
                        v.VisitorName,
                        v.CompanyName,
                        v.Mobile,
                        v.EmployeeName,
                        v.EmployeeDepartment,
                        v.EmployeeDesignation,
                        VisitTime = v.CreatedAt,
                        Status = v.VisitStatus.StatusName,
                        VisitorType = v.VisitorType.VisitorTypeName
                    })
                    .OrderByDescending(x => x.VisitTime)
                    .ToListAsync();

                return Ok(list);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    message = "Error fetching visitor list",
                    error = ex.Message
                });
            }
        }

        // GET: api/VisitorRequest/GetStatus
        [HttpGet("GetStatus")]
        public async Task<IActionResult> GetStatus()
        {
            var statusList = await _context.Visitstatuses.ToListAsync();
            return Ok(statusList);
        }

    }
    //  Helper Model for Forward Visitor Request API
    public class ForwardVisitorModel
    {
        public int VisitId { get; set; }
        public int StatusId { get; set; }
        public string? Remarks { get; set; }
        public string? ForwardedBy { get; set; }
    }
}
