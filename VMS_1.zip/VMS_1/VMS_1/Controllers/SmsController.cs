﻿// Controller
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;
using Twilio.Exceptions;
using VMS_1.Models;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Twilio.Clients;

[ApiController]
[Route("api/[controller]")]
public class SmsController : ControllerBase
{
    private readonly ITwilioRestClient _client;
    private readonly IConfiguration _config;

    public SmsController(ITwilioRestClient client, IConfiguration config)
    {
        _client = client;
        _config = config;
    }

    // helper: simple E.164 check (improve as needed)
    private bool IsE164(string number) =>
        !string.IsNullOrWhiteSpace(number) &&
        Regex.IsMatch(number, @"^\+\d{7,15}$");

    //[HttpPost("Sendsms")]
    //public async Task<IActionResult> SendSms([FromBody] SmsMessage model)
    //{
    //    // Use server-side FromNumber only
    //    var from = _config["Twilio:FromNumber"];
    //    var to = model?.To?.Trim();

    //    if (!IsE164(to))
    //    {
    //        return BadRequest("Recipient number must be in E.164 format (e.g. +919876543210).");
    //    }

    //    try
    //    {
    //        var message = await MessageResource.CreateAsync(
    //            to: new PhoneNumber(to),
    //            from: new PhoneNumber(from),
    //            body: model?.Message ?? string.Empty,
    //            client: _client
    //        );

    //        return Ok(new { success = true, sid = message.Sid, status = message.Status.ToString() });
    //    }
    //    catch (ApiException apiEx)
    //    {
    //        // Twilio API errors include a numeric code; log and return meaningful message
    //        // Example: 21608 = trial account sending to unverified number
    //        return StatusCode(500, new { success = false, error = apiEx.Message, code = apiEx.Code });
    //    }
    //    catch (Exception ex)
    //    {
    //        return StatusCode(500, new { success = false, error = ex.Message });
    //    }
    //}


    [HttpPost("Sendsms")]
    public async Task<IActionResult> SendSms([FromBody] SmsMessage model)
    {
        var from = _config["Twilio:FromNumber"]; // always backend number
        var to = model?.To?.Trim();

        if (!IsE164(to))
            return BadRequest("Recipient number must be in E.164 format.");

        try
        {
            var message = await MessageResource.CreateAsync(
                to: new PhoneNumber(to),
                from: new PhoneNumber(from),
                body: model?.Message ?? string.Empty,
                client: _client
            );

            return Ok(new { success = true, sid = message.Sid, status = message.Status.ToString() });
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { success = false, error = ex.Message });
        }
    }


}