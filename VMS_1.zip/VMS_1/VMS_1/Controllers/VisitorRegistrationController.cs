﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VMS_1.Models;
using YourNamespace.Helpers;

namespace VMS_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VisitorRegistrationController : ControllerBase
    {
        private readonly VMS_DBContext _context;
        private readonly TokenValidator _tokenValidator;

        public VisitorRegistrationController(VMS_DBContext context, IConfiguration config)
        {
            _context = context;
            _tokenValidator = new TokenValidator(config);
        }

        private bool IsTokenValid()
        {
            // Request.Cookies.TryGetValue("user_auth_token", out string token);
            var authHeader = Request.Headers["Authorization"].ToString();
            if (string.IsNullOrEmpty(authHeader) || !authHeader.StartsWith("Bearer "))
                return false;

            var token = authHeader.Replace("Bearer ", "");

            // Request.Cookies.TryGetValue("ref_token", out string token);
            return _tokenValidator.ValidateTokenFromCookie(token);

        }

        //  Get All Lookup Data (VisitorType, Gender, Purpose, etc.)

        [HttpGet("GetAllVisiter")]
        public IActionResult GetAllVisiter()
        
        {
            if (!IsTokenValid())
            {
                return Unauthorized(new { message = "Invalid or expired token" });

            }

            var lookups = new
            {
                VisitorTypes = _context.Visitortypes.ToList(),
                Genders = _context.Genders.ToList(),
                Departments = _context.Departments.ToList(),
                Designations = _context.Designations.ToList(),
                Purposes = _context.Purposes.ToList(),
                Gates = _context.Gates.ToList(),
                ItemTypes = _context.Itemtypes.ToList(),
                ItemScopes = _context.Itemscopes.ToList(),
                Countries = _context.Countries.ToList()
            };
            return Ok(lookups);
        }

        //  Add a new Visitor + Items
        [HttpPost("AddVisit")]
        public async Task<IActionResult> AddVisit([FromBody] Visit request)
        {
            if (request == null)
                return BadRequest("Invalid request");

            // Save main visit record
            request.CreatedAt = DateTime.UtcNow;
            _context.Visits.Add(request);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                success = true,
                message = "Visitor registered successfully",
                visitId = request.VisitId
            });
        }

        //  Get All Visits
        [HttpGet("GetVisits")]
        public async Task<IActionResult> GetVisits()
        {
            var data = await _context.Visits
                .Include(v => v.VisitorType)
                .Include(v => v.Gender)
                .Include(v => v.Purpose)
                .Include(v => v.InGate)
                .Include(v => v.Country)
                .Include(v => v.VisitStatus)
                .ToListAsync();

            return Ok(data);
        }
        //  Get Visit by ID (with items)
        [HttpGet("GetVisitById/{id}")]
        public async Task<IActionResult> GetVisitById(int id)
        {
            var visit = await _context.Visits
                .Include(v => v.Visititems)
                .FirstOrDefaultAsync(v => v.VisitId == id);

            if (visit == null)
                return NotFound(new { message = "Visit not found" });

            return Ok(visit);
        }
        //  Add Item for a Visit
        [HttpPost("AddVisitItem")]
        public async Task<IActionResult> AddVisitItem([FromBody] Visititem item)
        {
            if (item == null)
                return BadRequest("Invalid item data");

            item.CreatedAt = DateTime.UtcNow;
            _context.Visititems.Add(item);
            await _context.SaveChangesAsync();

            return Ok(new { success = true, message = "Item added successfully" });
        }
    }

}

