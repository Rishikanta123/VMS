﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Twilio.Clients;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;
using VMS_1.Models;

[ApiController]
[Route("api/[controller]")]
public class WhatsAppController : ControllerBase
{
    private readonly ITwilioRestClient _client;
    private readonly IConfiguration _config;

    public WhatsAppController(ITwilioRestClient client, IConfiguration config)
    {
        _client = client;
        _config = config;
    }

    private string NormalizeToWhatsApp(string rawNumber, string defaultCountryCode = "+91")
    {
        if (string.IsNullOrWhiteSpace(rawNumber)) return null;

        var num = rawNumber.Trim();

        num = num.Replace(" ", "")
                 .Replace("-", "")
                 .Replace("(", "")
                 .Replace(")", "");

        if (num.StartsWith("+"))
            return $"whatsapp:{num}";

        num = num.TrimStart('0');

        return $"whatsapp:{defaultCountryCode}{num}";
    }

    [HttpPost("SendWhatsApp")]
    public IActionResult SendWhatsApp([FromBody] SmsMessage model)
    {
        // Convert user-entered phone number → WhatsApp-format
        string toNumber = NormalizeToWhatsApp(model.To);

        // WhatsApp From number from appsettings.json
        string fromNumber = _config["Twilio:WhatsAppFrom"];
        // Example: "whatsapp:+14155238886"

        var msg = MessageResource.Create(
            to: new PhoneNumber(toNumber),
            from: new PhoneNumber(fromNumber),
            body: model.Message,
            client: _client
        );

        return Ok(new { sid = msg.Sid, status = msg.Status.ToString() });
    }
}
