﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using VMS_1.Models;
using Microsoft.Data.SqlClient;
using System.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity.Data;
using YourNamespace.Helpers;
using Microsoft.AspNetCore.Authorization;

namespace VMS_1.Controllers
{
    [Route("api/V2")]
    [ApiController]

 
    public class LoginController : ControllerBase
    {
        private readonly IConfiguration _config;
        private readonly VMS_DBContext _context;
        private readonly TokenValidator _tokenValidator;

        public LoginController(IConfiguration config, VMS_DBContext context)
        {
            _config = config;
            _context = context;
        }

        //  10 Set CSRF Token for user
        [HttpPost("SetCsrfToken")]
        public async Task<IActionResult> SetCsrfToken([FromBody] ReqCsrf param)
        {
            if (string.IsNullOrWhiteSpace(param.Username))
                return BadRequest("Username is required");

            var user = await _context.VmsLogins.FirstOrDefaultAsync(x => x.Username == param.Username);
            if (user == null)
                return NotFound("User not found");

            string csrfToken = Generate10DigitRandomNumber();
            user.Csrftoken = csrfToken;

            await _context.SaveChangesAsync();

            return Ok(new { message = csrfToken });
        }

        //  20 Validate login and issue JWT + cookies
        [HttpPost("validatinglogin")]
        public async Task<IActionResult> ValidatingLogin([FromBody] ReqValidatingLogin param)
        {
            if (param == null || string.IsNullOrEmpty(param.Username) || string.IsNullOrEmpty(param.Password))
                return BadRequest(new { success = false, message = "Invalid request" });

            var user = await _context.VmsLogins.FirstOrDefaultAsync(x => x.Username == param.Username);

            if (user == null)
                return Unauthorized(new { success = false, message = "Invalid username" });

            if (user.Csrftoken != param.CsrfToken)
                return Unauthorized(new { success = false, message = "Invalid CSRF token" });

            if (user.Password != param.Password)
                return Unauthorized(new { success = false, message = "Invalid password" });

            // ✅ Mask phone number
            string maskedPhone = string.IsNullOrEmpty(user.Phoneno)
                ? ""
                : "XXXXXXX" + user.Phoneno.Substring(Math.Max(0, user.Phoneno.Length - 3));

            int randomSixDigit = new Random().Next(100000, 999999);

            // ✅ Token payload (similar to your old system)
            string userData = $"{user.Username},{user.Status},{maskedPhone},{user.Empemail},{user.Id},{randomSixDigit}";

            // ✅ Generate tokens
            string token = GenerateJwtToken(userData);
            string refreshToken = GenerateRefreshToken(userData);

            // ✅ Update DB
            user.Emptoken = token;
            user.Tokenid = randomSixDigit.ToString();
            user.Csrftoken = null;
            user.Logintime = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            // ✅ Set Cookies (same as your old MVC project)
            //Response.Cookies.Append("user_auth_token", token, new CookieOptions
            //{
            //    HttpOnly = true,
            //    Secure = true,
            //    //Secure = false,
            //    //SameSite = SameSiteMode.None,
            //    SameSite = SameSiteMode.Lax,
            //    Expires = DateTime.UtcNow.AddHours(1),
            //    Domain = ".arihantcapital.com",
            //    Path = "/"
            //});


            //HttpContext.Response.Cookies.Append("ref_token", refreshToken, new CookieOptions
            //{
            //    HttpOnly = true,
            //    Secure = true,
            //    SameSite = SameSiteMode.None,
            //    Expires = DateTime.UtcNow.AddHours(1),
            //    Domain = ".arihantcapital.com",
            //    Path = "/"
            //});

            // ✅ Set Cookies with conditional Domain
            // ✅ Set Cookies with explicit headers
            var cookieOptions = new CookieOptions
            {
                HttpOnly = true,
                Secure = false,  // ← Set to false for localhost HTTP
                SameSite = SameSiteMode.Lax,
                Expires = DateTime.UtcNow.AddHours(1),
                Path = "/"
            };

            // Only set Domain and Secure for production
            if (!HttpContext.Request.Host.Host.Contains("localhost"))
            {
                cookieOptions.Secure = true;
                cookieOptions.Domain = ".arihantcapital.com";
            }

            Response.Cookies.Append("user_auth_token", token, cookieOptions);

            // For ref_token - use SameSite.Lax for localhost, None for production
            var refreshTokenCookieOptions = new CookieOptions
            {
                HttpOnly = true,
                Secure = false,  // ← Set to false for localhost HTTP
                SameSite = SameSiteMode.Lax,
                Expires = DateTime.UtcNow.AddHours(1),
                Path = "/"
            };

            if (!HttpContext.Request.Host.Host.Contains("localhost"))
            {
                refreshTokenCookieOptions.Secure = true;
                refreshTokenCookieOptions.SameSite = SameSiteMode.None;
                refreshTokenCookieOptions.Domain = ".arihantcapital.com";
            }

            HttpContext.Response.Cookies.Append("ref_token", refreshToken, refreshTokenCookieOptions);



            return Ok(new
            {
                success = true,
                message = "Login successful",
                Token = token,
                RefreshToken = refreshToken,
                Username = user.Username,
                EmployeeName = user.Employeename
            });
        }

        //  Helper Methods
        private string GenerateJwtToken(string username)
        {
            var keyString = _config["Jwt:Key"] ?? throw new InvalidOperationException("JWT key missing in config.");
            var key = Convert.FromBase64String(keyString);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, username) }),
                Expires = DateTime.UtcNow.AddMinutes(Convert.ToInt32(_config["Jwt:ExpireMinutes"] ?? "480")),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var handler = new JwtSecurityTokenHandler();
            var token = handler.CreateToken(tokenDescriptor);
            return handler.WriteToken(token);
        }

        private string GenerateRefreshToken(string username)
        {
            var keyString = _config["Jwt:Key"] ?? throw new InvalidOperationException("JWT key missing in config.");
            var key = Convert.FromBase64String(keyString);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, username) }),
                Expires = DateTime.UtcNow.AddMinutes(Convert.ToInt32(_config["Jwt:ExpireMinutes"] ?? "480")),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var handler = new JwtSecurityTokenHandler();
            var token = handler.CreateToken(tokenDescriptor);
            return handler.WriteToken(token);
        }

        private string Generate10DigitRandomNumber()
        {
            var random = new Random();
            return string.Concat(Enumerable.Range(0, 10).Select(_ => random.Next(0, 10).ToString()));
        }

        //private bool IsTokenValid()
        //{
        //    Request.Cookies.TryGetValue("user_auth_token", out string token);
        //    return _tokenValidator.ValidateTokenFromCookie(token);
        //}
        // POST: api/Login
        [AllowAnonymous]
        [HttpPost("getemployeelistbyusernameandpassword")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {

            //if (!IsTokenValid())
            //{
            //    return Unauthorized(new { message = "Invalid or expired token" });

            //}

            if (request == null ||
                string.IsNullOrWhiteSpace(request.Username) ||
                string.IsNullOrWhiteSpace(request.Password))
            {
                return BadRequest("Username and password required");
            }

            var user = await _context.VmsLogins
                .FirstOrDefaultAsync(x =>
                    x.Username == request.Username &&
                    x.Password == request.Password);

            if (user == null)
            {
                return Unauthorized(new { message = "Invalid username or password" });
            }

            user.Logintime = DateTime.Now;
            await _context.SaveChangesAsync();

            return Ok(new
            {
                message = "Login successful",
                user.Id,
                user.Employeecode,
                user.Employeename,
                user.Username,
                user.Phoneno,
                user.Empemail,
                user.Status,
                user.Empphoto
            });
        }

    }
    public class LoginRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }

}


