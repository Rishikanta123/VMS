﻿using Microsoft.Extensions.Configuration;
using System.Net.Http; // ← .NET HttpClient
using System.Threading.Tasks;
using Twilio.Clients;
using Twilio.Http;

namespace VMS_1.Services
{
    public class TwilioClient : ITwilioRestClient
    {
        private readonly ITwilioRestClient _innerClient;

        // FIX: Use System.Net.Http.HttpClient explicitly
        public TwilioClient(IConfiguration config, System.Net.Http.HttpClient httpClient=null)
        {
            // optional custom header
            httpClient.DefaultRequestHeaders.Add("X-Custom-Header", "CustomTwilioRestClient-Demo");

            _innerClient = new TwilioRestClient(
                config["Twilio:AccountSid"],
                config["Twilio:AuthToken"],
                // config["Twilio:AccountSid"],
                httpClient: new SystemNetHttpClient(httpClient) // Twilio wrapper
            );
        }

        public Response Request(Request request) => _innerClient.Request(request);
        public Task<Response> RequestAsync(Request request) => _innerClient.RequestAsync(request);
        public string AccountSid => _innerClient.AccountSid;
        public string Region => _innerClient.Region;

        // FIX: Must return Twilio.Http.HttpClient
        public Twilio.Http.HttpClient HttpClient => _innerClient.HttpClient;
    }
}
