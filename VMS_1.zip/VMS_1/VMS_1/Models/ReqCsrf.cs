﻿namespace VMS_1.Models
{
    public class ReqCsrf
    {
        public string Username { get; set; }
    }
    public class ReqValidatingLogin
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string CsrfToken { get; set; }
    }
}




