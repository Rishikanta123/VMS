﻿namespace VMS_1.Models
{
    public static class Setting
    {
        // MUST BE REAL TWILIO ACCOUNT SID
        public static string APIKEY = "ACxxxxxxxxxxxxxxxxxxxxxxxxxxxx";

        // MUST BE REAL TWILIO AUTH TOKEN
        public static string APISECRET = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxx";

        // Twilio WhatsApp Sandbox number
        public static string WhatsappFrom = "whatsapp:+14155238886";

        // Your WhatsApp number (must join sandbox)
        public static string WhatsappTo = "whatsapp:+917749014649";
    }
}
