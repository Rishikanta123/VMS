﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;

namespace YourNamespace.Helpers
{
    public class TokenValidator
    {
        private readonly IConfiguration _config;

        public TokenValidator(IConfiguration config)
        {
            _config = config;
        }

        public bool ValidateTokenFromCookie(string token)
        {
            if (string.IsNullOrEmpty(token))
                return false;

            try
            {
                // Read secret key from appsettings.json
                var keyString = _config["Jwt:Key"];

                // Convert Base64 key to bytes
                var key = Convert.FromBase64String(keyString);

                // Setup token validation parameters
                var validations = new TokenValidationParameters
                {
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key)
                };

                // Validate token via handler
                var handler = new JwtSecurityTokenHandler();
                handler.ValidateToken(token, validations, out _);

                return true;  // VALID TOKEN
            }
            catch
            {
                return false; // INVALID TOKEN
            }
        }
    }
}
